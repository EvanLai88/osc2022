#ifndef _MALLOC_H
#define _MALLOC_H

void* kmalloc(unsigned int size);
void free(void *ptr);
#endif
#ifndef _LIB_H
#define _LIB_H

int strcmp(char *s1, char *s2);
int len(char *s);
int atoi(char *s);

#endif
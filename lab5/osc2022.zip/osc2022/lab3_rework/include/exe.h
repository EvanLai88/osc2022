#ifndef _EXE_H
#define _EXE_H

#define USER_STACK_SIZE    0x1000

int exe(void *file);

#endif
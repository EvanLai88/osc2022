#include "syscall.h"
#include "sched.h"
#include "uart.h"
#include "malloc.h"
#include "cpio.h"
#include "mbox.h"
// #include "signal.h"

int getpid(trapframe_t* tpf)
{
    tpf->x0 = curr_thread->pid;
    return curr_thread->pid;
}

size_t uart_read(trapframe_t *tpf,char buf[], size_t size)
{
    int i = 0;
    for (int i = 0; i < size;i++)
    {
        buf[i] = uart_async_getc();
    }
    tpf->x0 = i;
    return i;
}

size_t uart_write(trapframe_t *tpf,const char buf[], size_t size)
{
    int i = 0;
    for (int i = 0; i < size; i++)
    {
        uart_async_putc(buf[i]);
    }
    tpf->x0 = i;
    return i;
}

int exec(trapframe_t *tpf,const char *name, char *const argv[])
{
    curr_thread->code_size = cpio_file_size((char*)name);
    char *new_code = cpio_file_start((char *)name);
    for (unsigned int i = 0; i < curr_thread->code_size;i++)
    {
        curr_thread->code[i] = new_code[i];
    }

    //clear signal handler
    // for (int i = 0; i <= SIGNAL_MAX; i++)
    // {
    //     curr_thread->singal_handler[i] = signal_default_handler;
    // }

    tpf->elr_el1 = (unsigned long)curr_thread->code;
    tpf->sp_el0 = (unsigned long)curr_thread->ustack + UT_STACK_SIZE;
    tpf->x0 = 0;
    return 0;
}

int fork(trapframe_t *tpf)
{
    disable_interrupt();
    thread_t *newt = thread_create(curr_thread->code);

    //copy signal handler
    // for (int i = 0; i <= SIGNAL_MAX;i++)
    // {
    //     newt->singal_handler[i] = curr_thread->singal_handler[i];
    // }

    newt->code_size = curr_thread->code_size;
    int parent_pid = curr_thread->pid;
    thread_t *parent_thread_t = curr_thread;

    //Cannot copy data because there are a lot of ret addresses on stack
    //copy user stack into new process
    for (int i = 0; i < UT_STACK_SIZE; i++)
    {
        newt->ustack[i] = curr_thread->ustack[i];
    }

    //copy stack into new process
    for (int i = 0; i < KT_STACK_SIZE; i++)
    {
        newt->kstack[i] = curr_thread->kstack[i];
    }
    
    store_context(get_current());
    //for child
    if( parent_pid != curr_thread->pid)
    {
        goto child;
    }

    newt->context = curr_thread->context;
    newt->context.fp += newt->kstack - curr_thread->kstack; // move fp
    newt->context.sp += newt->kstack - curr_thread->kstack; // move kernel sp
    //cannot use this??
    //newt->context.lr = (unsigned long)&&child;                                                // move lr

    enable_interrupt();

    tpf->x0 = newt->pid;
    return newt->pid;

child:
    tpf = (trapframe_t*)((char *)tpf + (unsigned long)newt->kstack - (unsigned long)parent_thread_t->kstack); // move tpf
    tpf->sp_el0 += newt->ustack - parent_thread_t->ustack;
    tpf->x0 = 0;
    return 0;
}

void exit(trapframe_t *tpf, int status)
{
    thread_exit();
}

int sys_mbox_call(trapframe_t *tpf, unsigned char ch, unsigned int *mbox)
{
    disable_interrupt();
    unsigned long r = (((unsigned long)((unsigned long)mbox) & ~0xF) | (ch & 0xF));
    /* wait until we can write to the mailbox */
    do{asm volatile("nop");} while (*MBOX_STATUS & MBOX_FULL);
    /* write the address of our message to the mailbox with channel identifier */
    *MBOX_WRITE = r;
    /* now wait for the response */
    while (1)
    {
        /* is there a response? */
        do
        {
            asm volatile("nop");
        } while (*MBOX_STATUS & MBOX_EMPTY);
        /* is it a response to our message? */
        if (r == *MBOX_READ)
        {
            /* is it a valid successful response? */
            tpf->x0 = (mbox[1] == MBOX_RESPONSE);
            enable_interrupt();
            return mbox[1] == MBOX_RESPONSE;
        }
    }

    tpf->x0 = 0;
    enable_interrupt();
    return 0;
}

void kill(trapframe_t *tpf,int pid)
{
    disable_interrupt();
    if (pid >= PID_MAX || pid < 0  || !threads[pid].in_use)
    {
        enable_interrupt();
        return;
    }
    threads[pid].state = ZOMBIE;
    enable_interrupt();
    schedule();
}

// void signal_register(int signal, void (*handler)())
// {
//     if (signal > SIGNAL_MAX || signal < 0)return;

//     curr_thread->singal_handler[signal] = handler;
// }

// void signal_kill(int pid, int signal)
// {
//     if (pid > PIDMAX || pid < 0 || !threads[pid].isused)return;

//     lock();
//     threads[pid].sigcount[signal]++;
//     enable_interrupt();
// }

// void sigreturn(trapframe_t *tpf)
// {
//     unsigned long signal_ustack = tpf->sp_el0 % USTACK_SIZE == 0 ? tpf->sp_el0 - USTACK_SIZE : tpf->sp_el0 & (~(USTACK_SIZE - 1));
//     kfree((char*)signal_ustack);
//     load_context(&curr_thread->signal_saved_context);
// }

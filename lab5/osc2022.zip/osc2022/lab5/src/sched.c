#include "sched.h"
#include "malloc.h"
#include "exception.h"
#include "timer.h"
#include "uart.h"

void sched_init()
{
    disable_interrupt();
    run_queue = kmalloc(sizeof(list_head_t));
    wait_queue = kmalloc(sizeof(list_head_t));
    INIT_LIST_HEAD(run_queue);
    INIT_LIST_HEAD(wait_queue);

    pid_count = 0;
    for (int i=0; i<PID_MAX; i++)
    {
        threads[i].pid = i;
        threads[i].in_use = 0;
        threads[i].state = UNINITIALIZED;
        threads[i].priority = PRIORITY_MEDIUM;
    }

    asm volatile("msr tpidr_el1, %0" ::"r"(kmalloc(sizeof(thread_t)))); /// malloc a space for current kernel thread to prevent crash

    thread_t* idlethread = thread_create(idle);
    curr_thread = idlethread;
    enable_interrupt();
}

thread_t *thread_create(void *executable)
{
    disable_interrupt();
    thread_t *thd = (thread_t *) 0;

    // find a unused pid
    if (pid_count >= PID_MAX) {return (thread_t *)-1;}
    for(int i=0;i<PID_MAX;i++)
    {
        if(!threads[i].in_use)
        {
            thd = &threads[i];
            break;
        }
    }
    pid_count++;

    thd->in_use = 1;
    thd->state = RUNNABLE;
    thd->context.lr = (uint64_t)executable;

    thd->ustack = kmalloc(UT_STACK_SIZE);
    thd->context.sp = (uint64_t)thd->ustack + UT_STACK_SIZE;
    thd->context.fp = thd->context.sp;
    thd->kstack = kmalloc(KT_STACK_SIZE);

    list_add(&(thd->listhead), run_queue);
    enable_interrupt();
    return thd;
}

void idle()
{
    while(1) {
        uart_puts("\tidle thread\n");
        kill_zombie();
        schedule();
    }
}

int exec_thread(char *code, unsigned int filesize)
{
    thread_t *t = thread_create(code);
    t->code = kmalloc(filesize);
    t->code_size = filesize;
    t->context.lr = (unsigned long)t->code;

    for (int i = 0; i < filesize;i++)
    {
        t->code[i] = code[i];
    }

    curr_thread = t;
    add_timer_second(sched_timer, 1, "");

    asm("msr tpidr_el1,     %0\n"
        "msr elr_el1,       %1\n"
        "msr spsr_el1,      xzr\n"
        "msr sp_el0,        %2\n"
        // "mov sp,            %3\n"
        "eret\n"
        ::
        "r"(&t->context),
        "r"(t->context.lr),
        "r"(t->context.sp)
        // "r"(t->kstack + KT_STACK_SIZE)
        );

    return 0;
}

void schedule()
{
    disable_interrupt();
    if (curr_thread->state == RUNNING) {
        curr_thread->state = RUNNABLE;
    }
    do {
        curr_thread = (thread_t *)curr_thread->listhead.next;
    } while (list_is_head(&curr_thread->listhead, run_queue) || curr_thread->state == ZOMBIE);
    curr_thread->state = RUNNING;
    enable_interrupt();

    switch_to(get_current(), &curr_thread->context);
}

void thread_exit()
{
    disable_interrupt();
    // uart_puts("Exit pid: ");
    // uart_int(curr_thread->pid);
    // uart_puts("\n");
    // uart_puts("\tstate: ");
    // uart_int(curr_thread->state);
    // uart_puts("\n");
    curr_thread->state = ZOMBIE;
    // uart_puts("\n");
    // uart_puts("\tstate: ");
    // uart_int(curr_thread->state);
    // uart_puts("\n");
    enable_interrupt();
    schedule();
}

void kill_zombie()
{
    disable_interrupt();
    list_head_t *curr;
    list_for_each(curr, run_queue)
    {
        // uart_puts("Thread pid: ");
        // uart_int(((thread_t *)curr)->pid);
        // uart_puts("\n");
        // uart_puts("\tstate: ");
        // uart_int(((thread_t *)curr)->state);
        // uart_puts("\n");
        if (((thread_t *)curr)->state == ZOMBIE)
        {
            uart_puts("kill zombie\n");
            list_del_entry(curr);
            kfree(((thread_t *)curr)->ustack);
            kfree(((thread_t *)curr)->kstack);
            kfree(((thread_t *)curr)->code);
            ((thread_t *)curr)->state = UNINITIALIZED;
            ((thread_t *)curr)->in_use = 0;
            pid_count--;
        }
    }
    enable_interrupt();
}

void sched_timer()
{
    add_timer_tick(sched_timer, get_timer_frq()>>6, "");
}
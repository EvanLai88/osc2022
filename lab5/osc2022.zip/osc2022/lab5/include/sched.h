#ifndef __SCHED_H
#define __SCHED_H

#include "compiler.h"
#include "list.h"

#define PID_MAX             65536
#define UT_STACK_SIZE       0x10000
#define KT_STACK_SIZE       0x10000

#define UNINITIALIZED       0x0000
#define RUNNING             0x0001
#define RUNNABLE            0x0002
#define SLEEP               0x0003
#define INTERRUPTABLE       0x0004
#define UNINTERRUPTABLE     0x0004
#define ZOMBIE              0xffff

#define PRIORITY_HIGH       0x0000
#define PRIORITY_MEDIUM     0x0001
#define PRIORITY_LOW        0x0002

extern void switch_to(void *curr_cont, void *next_cont);
extern void store_context(void *curr_cont);
extern void load_context(void *curr_cont);
extern void *get_current();

typedef struct thread_context
{
    uint64_t    x19;
    uint64_t    x20;
    uint64_t    x21;
    uint64_t    x22;
    uint64_t    x23;
    uint64_t    x24;
    uint64_t    x25;
    uint64_t    x26;
    uint64_t    x27;
    uint64_t    x28;
    uint64_t    fp;
    uint64_t    lr;
    uint64_t    sp;
} thread_context_t;

typedef struct thread
{
    list_head_t         listhead;
    int                 pid;
    int                 in_use;
    int                 state;
    int                 priority;

    char*               code;           // need to be freed
    uint32_t            code_size;
    thread_context_t    context;        // need to be freed
    char*               ustack;         // need to be freed
    char*               kstack;         // need to be freed
} thread_t;


thread_t threads[PID_MAX + 1];
thread_t *curr_thread;
list_head_t *run_queue;
list_head_t *wait_queue;

int pid_count;

void sched_init();
thread_t *thread_create(void *executable);
int exec_thread(char* code, uint32_t filesize);
void idle();
void schedule();
void thread_exit();
void kill_zombie();
void sched_timer();


#endif
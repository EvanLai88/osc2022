python3 load_kernel.py $1 $2
screen $1 115200
